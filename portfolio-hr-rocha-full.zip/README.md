# Portfólio — H. R. Rocha (Skills Intermediário + 3 Projetos)

Este pacote contém o portfólio com visual futurista e três projetos simples:

- **To-Do Minimal** — LocalStorage e acessibilidade no teclado
- **Calculadora Simples** — quatro operações e suporte ao teclado
- **Contador/Timer** — contador e timer regressivo com ARIA-live

## Como publicar (GitHub Pages)
1) Faça upload de TUDO para seu repositório.
2) Em *Settings → Pages*: Branch `principal/main`, folder `/ (root)`.
3) Acesse a URL do Pages.
